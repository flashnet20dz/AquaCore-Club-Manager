"use client";

import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload, FileSpreadsheet, Loader2, CheckCircle2, AlertCircle, XCircle, Eye, ArrowRight, Database,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

interface PreviewRow {
  row: number;
  lastName: string;
  firstName: string;
  birthDate: string | null;
  gender: string | null;
  subscriptionType: string | null;
  paymentStatus: string | null;
  phone: string | null;
  errors: string[];
  computed: {
    age: number;
    subscriptionFee: number | null;
    insuranceFee: number | null;
    compoundRights: number | null;
    totalAmount: number | null;
  };
  rightsRule: string;
}

interface PreviewResult {
  preview: boolean;
  totalRows: number;
  validRows: number;
  errorRows: number;
  warnings: number;
  detectedColumns: Record<string, string | null>;
  sample: PreviewRow[];
  errorSamples: PreviewRow[];
  summary: {
    totalFees: number;
    totalInsurance: number;
    totalCompound: number;
    totalRevenue: number;
  };
}

export function ImportPanel() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [preview, setPreview] = useState<PreviewResult | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.name.endsWith(".xlsx") && !f.name.endsWith(".xls")) {
      toast.error("يجب أن يكون الملف بصيغة Excel (.xlsx أو .xls)");
      return;
    }
    setFile(f);
    setPreview(null);
  };

  const handlePreview = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("dryRun", "true");

      const res = await fetch("/api/import", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setPreview(data);
      toast.success(`تم تحليل الملف: ${data.validRows} صف صالح من ${data.totalRows}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل التحليل");
    } finally {
      setLoading(false);
    }
  };

  const handleImport = async () => {
    if (!file) return;
    setImporting(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/import", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      toast.success(`تم استيراد ${data.imported} منخرط بنجاح!`);
      setFile(null);
      setPreview(null);
      if (inputRef.current) inputRef.current.value = "";
      // Trigger refresh
      window.location.reload();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل الاستيراد");
    } finally {
      setImporting(false);
    }
  };

  const handleReset = () => {
    setFile(null);
    setPreview(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  return (
    <div className="space-y-4">
      {/* Upload card */}
      <div className="rounded-2xl border border-border/60 bg-card p-5">
        <h3 className="font-bold text-base mb-1 flex items-center gap-2">
          <Database className="h-5 w-5 text-primary" /> استيراد المنخرطين من Excel
        </h3>
        <p className="text-xs text-muted-foreground mb-4">
          ارفع ملف Excel يحتوي على بيانات المنخرطين (اللقب، الاسم، تاريخ الميلاد، الجنس، نوع الاشتراك، حالة الدفع...). سيتم تدقيق كل البيانات والتحقق من الحسابات المالية تلقائياً.
        </p>

        {/* Drop zone */}
        <div
          onClick={() => inputRef.current?.click()}
          className="border-2 border-dashed border-border rounded-2xl p-8 text-center hover:border-primary/50 hover:bg-accent/40 transition cursor-pointer"
        >
          <input
            ref={inputRef}
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileSelect}
            className="hidden"
          />
          <FileSpreadsheet className="h-12 w-12 mx-auto mb-3 text-primary/60" />
          {file ? (
            <div>
              <p className="font-semibold text-sm">{file.name}</p>
              <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</p>
            </div>
          ) : (
            <div>
              <p className="font-semibold text-sm mb-1">اضغط لاختيار ملف Excel</p>
              <p className="text-xs text-muted-foreground">يدعم صيغ .xlsx و .xls</p>
            </div>
          )}
        </div>

        {file && (
          <div className="flex items-center gap-2 mt-4 justify-center">
            <Button onClick={handlePreview} disabled={loading} variant="outline">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Eye className="h-4 w-4 ml-1" />}
              معاينة وتدقيق
            </Button>
            <Button onClick={handleReset} variant="ghost">
              إزالة الملف
            </Button>
          </div>
        )}
      </div>

      {/* Preview results */}
      <AnimatePresence>
        {preview && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="space-y-4"
          >
            {/* Summary */}
            <div className="rounded-2xl border border-border/60 bg-gradient-to-br from-teal-500/5 to-transparent p-5">
              <h3 className="font-bold text-base mb-3 flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" /> نتائج التحليل والتدقيق
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                <StatBox label="إجمالي الصفوف" value={preview.totalRows} color="bg-sky-500/10 text-sky-700" />
                <StatBox label="صفوف صالحة" value={preview.validRows} color="bg-emerald-500/10 text-emerald-700" />
                <StatBox label="صفوف بأخطاء" value={preview.errorRows} color="bg-rose-500/10 text-rose-700" />
                <StatBox label="تحذيرات" value={preview.warnings} color="bg-amber-500/10 text-amber-700" />
              </div>

              {/* Financial verification */}
              <div className="rounded-xl bg-card p-3 border border-border/60">
                <p className="text-xs font-bold text-muted-foreground mb-2 uppercase">التدقيق المالي (للصفوف الصالحة)</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">إجمالي رسوم الاشتراك</p>
                    <p className="font-bold tabular-nums">{preview.summary.totalFees.toLocaleString("en-US")} دج</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">إجمالي التأمين</p>
                    <p className="font-bold tabular-nums">{preview.summary.totalInsurance.toLocaleString("en-US")} دج</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">حقوق الديوان</p>
                    <p className="font-bold tabular-nums text-teal-700">{preview.summary.totalCompound.toLocaleString("en-US")} دج</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">الإيرادات الإجمالية</p>
                    <p className="font-bold tabular-nums text-amber-700">{preview.summary.totalRevenue.toLocaleString("en-US")} دج</p>
                  </div>
                </div>
              </div>

              {/* Detected columns */}
              <div className="mt-3 rounded-xl bg-card p-3 border border-border/60">
                <p className="text-xs font-bold text-muted-foreground mb-2 uppercase">الأعمدة المكتشفة</p>
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries(preview.detectedColumns).map(([key, val]) => (
                    <Badge key={key} variant="outline" className={val ? "bg-emerald-500/10 text-emerald-700" : "bg-rose-500/10 text-rose-700"}>
                      {val ? <CheckCircle2 className="h-3 w-3 ml-1" /> : <XCircle className="h-3 w-3 ml-1" />}
                      {key}: {val || "غير موجود"}
                    </Badge>
                  ))}
                </div>
              </div>

              {preview.validRows > 0 && (
                <div className="mt-4 flex items-center justify-center gap-2">
                  <Button onClick={handleImport} disabled={importing} size="lg">
                    {importing ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4 ml-1" />}
                    استيراد {preview.validRows} منخرط
                  </Button>
                </div>
              )}
            </div>

            {/* Sample preview */}
            {preview.sample.length > 0 && (
              <div className="rounded-2xl border border-border/60 bg-card p-4">
                <h4 className="font-bold text-sm mb-3 flex items-center gap-2">
                  <Eye className="h-4 w-4 text-primary" /> معاينة عينة (10 صفوف)
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b text-right">
                        <th className="p-1.5 font-semibold">#</th>
                        <th className="p-1.5 font-semibold">اللقب</th>
                        <th className="p-1.5 font-semibold">الاسم</th>
                        <th className="p-1.5 font-semibold">الميلاد</th>
                        <th className="p-1.5 font-semibold">الجنس</th>
                        <th className="p-1.5 font-semibold">النوع</th>
                        <th className="p-1.5 font-semibold">الدفع</th>
                        <th className="p-1.5 font-semibold">الرسوم</th>
                        <th className="p-1.5 font-semibold">التأمين</th>
                        <th className="p-1.5 font-semibold">الإجمالي</th>
                        <th className="p-1.5 font-semibold">الديوان</th>
                      </tr>
                    </thead>
                    <tbody>
                      {preview.sample.map((r) => (
                        <tr key={r.row} className="border-b hover:bg-accent/40">
                          <td className="p-1.5 text-muted-foreground">{r.row}</td>
                          <td className="p-1.5 font-semibold">{r.lastName}</td>
                          <td className="p-1.5">{r.firstName}</td>
                          <td className="p-1.5">{r.birthDate ? new Date(r.birthDate).toISOString().split("T")[0].replace(/-/g,"/") : "-"}</td>
                          <td className="p-1.5">{r.gender || "-"}</td>
                          <td className="p-1.5">{r.subscriptionType}</td>
                          <td className="p-1.5">{r.paymentStatus}</td>
                          <td className="p-1.5 tabular-nums">{r.computed.subscriptionFee ?? "-"}</td>
                          <td className="p-1.5 tabular-nums">{r.computed.insuranceFee ?? "-"}</td>
                          <td className="p-1.5 tabular-nums font-bold text-amber-700">{r.computed.totalAmount ?? "-"}</td>
                          <td className="p-1.5 tabular-nums text-teal-700">{r.computed.compoundRights ?? "-"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Error samples */}
            {preview.errorSamples.length > 0 && (
              <div className="rounded-2xl border border-rose-500/30 bg-rose-500/5 p-4">
                <h4 className="font-bold text-sm mb-3 flex items-center gap-2 text-rose-700">
                  <AlertCircle className="h-4 w-4" /> صفوف تحتوي على أخطاء (10 عينات)
                </h4>
                <div className="space-y-2">
                  {preview.errorSamples.map((r) => (
                    <div key={r.row} className="rounded-lg bg-card p-2 border border-rose-200/50">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold">صف #{r.row}: {r.lastName} {r.firstName}</span>
                      </div>
                      <ul className="text-xs text-rose-700 list-disc pr-4 space-y-0.5">
                        {r.errors.map((err, i) => <li key={i}>{err}</li>)}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatBox({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className={`rounded-xl p-3 ${color}`}>
      <p className="text-2xl font-extrabold tabular-nums">{value}</p>
      <p className="text-xs">{label}</p>
    </div>
  );
}
