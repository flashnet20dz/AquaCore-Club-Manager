"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FileSpreadsheet, FileText, Users, Calendar, RefreshCw, Wallet,
  Download, Loader2, ShieldCheck, Building2, Inbox, FileType,
  PenTool, Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ExportOption {
  type: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  narrow?: boolean; // For "étroites" margins
}

const EXPORTS: ExportOption[] = [
  { type: "subscribers", title: "قائمة المنخرطين", description: "جميع البيانات + الملخص الإحصائي", icon: Users, color: "from-teal-500/15 to-teal-500/5 border-teal-500/30" },
  { type: "insurance", title: "قائمة التأمين", description: "اللقب، الاسم، تاريخ الميلاد", icon: ShieldCheck, color: "from-emerald-500/15 to-emerald-500/5 border-emerald-500/30" },
  { type: "compound", title: "حقوق ديوان المركب", description: "اللقب، الاسم، المبلغ (1000 دج لكل منخرط)", icon: Building2, color: "from-sky-500/15 to-sky-500/5 border-sky-500/30" },
  { type: "incoming", title: "قائمة الوارد", description: "سجل المدفوعات الواردة — هوامش ضيقة", icon: Inbox, color: "from-violet-500/15 to-violet-500/5 border-violet-500/30", narrow: true },
  { type: "attendance", title: "سجل الحضور", description: "سجلات الحضور اليومية", icon: Calendar, color: "from-amber-500/15 to-amber-500/5 border-amber-500/30" },
  { type: "renewals", title: "سجل التجديدات", description: "تاريخ تجديدات الاشتراكات", icon: RefreshCw, color: "from-fuchsia-500/15 to-fuchsia-500/5 border-fuchsia-500/30" },
  { type: "financial", title: "التقرير المالي", description: "تفصيل الرسوم + الملخص المالي", icon: Wallet, color: "from-rose-500/15 to-rose-500/5 border-rose-500/30" },
];

const SIGNATURES = [
  { id: "president", label: "إمضاء رئيس الجمعية" },
  { id: "branch", label: "رئيس الفرع" },
  { id: "manager", label: "مدير الوحدة" },
  { id: "compound", label: "مدير ديوان المركب" },
  { id: "insurance", label: "تأشيرة التأمين" },
];

export function ExportPanel() {
  const [downloading, setDownloading] = useState<string | null>(null);
  const [sigModal, setSigModal] = useState<{ open: boolean; type: string; format: string } | null>(null);
  const [selectedSigs, setSelectedSigs] = useState<string[]>(["president", "branch"]);

  const toggleSig = (id: string) => {
    setSelectedSigs((prev) => prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]);
  };

  const handleExport = async (type: string, format: "xlsx" | "pdf" | "word") => {
    // For Word and PDF, show signature selection first
    if (format === "word" || format === "pdf") {
      setSigModal({ open: true, type, format });
      return;
    }
    // Excel: direct export
    await doExport(type, format, []);
  };

  const doExport = async (type: string, format: string, sigs: string[]) => {
    setDownloading(`${type}-${format}`);
    setSigModal(null);
    try {
      const params = new URLSearchParams({ format, type });
      if (sigs.length > 0) params.set("sigs", sigs.join(","));
      const res = await fetch(`/api/export?${params.toString()}`);
      if (!res.ok) throw new Error("فشل التصدير");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const filename = res.headers.get("Content-Disposition")?.split('filename="')[1]?.split('"')[0] || `RCS_${type}.${format === "word" ? "doc" : format}`;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success(`تم تصدير ${filename}`);
    } catch {
      toast.error("فشل التصدير");
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* En-tête preview */}
      <div className="rounded-2xl border border-border/60 bg-gradient-to-br from-teal-500/5 to-transparent p-4">
        <h3 className="font-bold text-sm mb-1 flex items-center gap-2">
          <FileText className="h-4 w-4 text-primary" /> الترويسة الموحدة (EN-TETE)
        </h3>
        <p className="text-xs text-muted-foreground mb-3">
          جميع القوائم تحتوي على الترويسة الموحدة + اختيار الإمضاءات قبل التصدير
        </p>
        <div className="rounded-xl bg-white border border-border p-3 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="w-12 h-12 rounded-lg bg-teal-500/10 flex items-center justify-center text-teal-700 text-xs font-bold">شعار</div>
            <div className="text-center flex-1 mx-2">
              <p className="text-sm font-bold text-teal-700">النادي الهاوي متعدد الرياضات</p>
              <p className="text-xs font-bold text-amber-600">الرائد - سعيدة</p>
              <p className="text-[10px] text-gray-500">فرع السباحة</p>
            </div>
            <div className="w-12 h-12 rounded-lg bg-teal-500/10 flex items-center justify-center text-teal-700 text-xs font-bold">شعار</div>
          </div>
          <div className="flex items-center justify-between mt-2 pt-2 border-t text-[10px] text-gray-600">
            <span className="font-semibold">الرقم: . . ./ن.ر.ه.ر.س {new Date().getFullYear()}</span>
            <span className="font-semibold">سعيدة في: {new Date().toISOString().split("T")[0].replace(/-/g,"/").replace(/\//g, "/")}</span>
          </div>
        </div>
      </div>

      {/* Export options */}
      <div className="rounded-2xl border border-border/60 bg-card p-4">
        <h3 className="font-bold text-sm mb-1 flex items-center gap-2">
          <Download className="h-4 w-4 text-primary" /> مركز التصدير
        </h3>
        <p className="text-xs text-muted-foreground mb-4">صدّر تقارير المنظومة بصيغة Word أو PDF أو Excel — مع الإمضاءات والترويسة الموحدة</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {EXPORTS.map((opt, i) => {
            const Icon = opt.icon;
            return (
              <motion.div
                key={opt.type}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className={cn("rounded-2xl border-2 bg-gradient-to-br p-4", opt.color)}
              >
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/60 dark:bg-black/20">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm">{opt.title}</p>
                    <p className="text-xs text-muted-foreground">{opt.description}</p>
                    {opt.narrow && <Badge variant="outline" className="mt-1 text-[9px] h-4 px-1 bg-violet-500/10 text-violet-700 border-violet-500/30">هوامش ضيقة</Badge>}
                  </div>
                </div>
                <div className="flex gap-1.5 mt-3">
                  <Button size="sm" variant="outline" className="flex-1 h-9 text-xs bg-white/60 dark:bg-black/20" onClick={() => handleExport(opt.type, "word")} disabled={downloading === `${opt.type}-word`}>
                    {downloading === `${opt.type}-word` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileType className="h-3.5 w-3.5 ml-1" />} Word
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 h-9 text-xs bg-white/60 dark:bg-black/20" onClick={() => handleExport(opt.type, "pdf")} disabled={downloading === `${opt.type}-pdf`}>
                    {downloading === `${opt.type}-pdf` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileText className="h-3.5 w-3.5 ml-1" />} PDF
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 h-9 text-xs bg-white/60 dark:bg-black/20" onClick={() => handleExport(opt.type, "xlsx")} disabled={downloading === `${opt.type}-xlsx`}>
                    {downloading === `${opt.type}-xlsx` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileSpreadsheet className="h-3.5 w-3.5 ml-1" />} Excel
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Signature selection modal */}
      <AnimatePresence>
        {sigModal?.open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setSigModal(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-card rounded-2xl p-6 max-w-md w-full space-y-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-2">
                <PenTool className="h-5 w-5 text-primary" />
                <h3 className="font-bold text-base">اختيار الإمضاءات</h3>
              </div>
              <p className="text-xs text-muted-foreground">اختر الإمضاءات التي تريد إظهارها في أسفل الملف. ستظهر في سطر واحد متساوية.</p>
              <div className="space-y-2">
                {SIGNATURES.map((sig) => (
                  <button
                    key={sig.id}
                    onClick={() => toggleSig(sig.id)}
                    className={cn(
                      "w-full flex items-center gap-3 p-3 rounded-xl border-2 text-sm transition",
                      selectedSigs.includes(sig.id) ? "border-primary bg-primary/10" : "border-border hover:bg-accent"
                    )}
                  >
                    <div className={cn("h-5 w-5 rounded-md border-2 flex items-center justify-center", selectedSigs.includes(sig.id) ? "bg-primary border-primary text-primary-foreground" : "border-border")}>
                      {selectedSigs.includes(sig.id) && <Check className="h-3 w-3" strokeWidth={3} />}
                    </div>
                    <span className="font-medium">{sig.label}</span>
                  </button>
                ))}
              </div>
              <div className="flex gap-2 pt-2 border-t">
                <Button variant="outline" className="flex-1" onClick={() => setSigModal(null)}>إلغاء</Button>
                <Button className="flex-1" onClick={() => doExport(sigModal.type, sigModal.format, selectedSigs)}>
                  <Download className="h-4 w-4 ml-1" /> تصدير {sigModal.format === "word" ? "Word" : "PDF"}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
