"use client";

import { useEffect, useState } from "react";
import { Settings as SettingsIcon, Save, Loader2, Building, Phone, MessageSquare, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

export function SettingsPanel() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => setSettings(d.settings || {}))
      .catch(() => toast.error("تعذر تحميل الإعدادات"))
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings }),
      });
      if (!res.ok) throw new Error();
      toast.success("تم حفظ الإعدادات");
    } catch {
      toast.error("فشل الحفظ");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-border/60 bg-card p-5">
        <h3 className="font-bold text-base mb-1 flex items-center gap-2">
          <SettingsIcon className="h-5 w-5 text-primary" /> إعدادات النادي
        </h3>
        <p className="text-xs text-muted-foreground mb-4">عدّل معلومات النادي الأساسية</p>

        <div className="space-y-4">
          {/* Club info */}
          <section className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
              <Building className="h-3 w-3" /> معلومات النادي
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm">اسم النادي</Label>
                <Input
                  value={settings.clubName || ""}
                  onChange={(e) => setSettings({ ...settings, clubName: e.target.value })}
                  className="h-10"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm">العنوان</Label>
                <Input
                  value={settings.clubAddress || ""}
                  onChange={(e) => setSettings({ ...settings, clubAddress: e.target.value })}
                  className="h-10"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm flex items-center gap-1.5"><Phone className="h-3 w-3" /> هاتف النادي</Label>
                <Input
                  value={settings.clubPhone || ""}
                  onChange={(e) => setSettings({ ...settings, clubPhone: e.target.value })}
                  className="h-10"
                  dir="ltr"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm flex items-center gap-1.5"><DollarSign className="h-3 w-3" /> العملة</Label>
                <Input
                  value={settings.currency || ""}
                  onChange={(e) => setSettings({ ...settings, currency: e.target.value })}
                  className="h-10"
                />
              </div>
            </div>
          </section>

          {/* WhatsApp */}
          <section className="space-y-3 pt-3 border-t">
            <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
              <MessageSquare className="h-3 w-3" /> إعدادات WhatsApp
            </h4>
            <div className="flex items-center justify-between rounded-xl bg-muted/40 p-3">
              <div>
                <p className="text-sm font-semibold">تفعيل إشعارات WhatsApp</p>
                <p className="text-xs text-muted-foreground">السماح بإرسال تذكيرات التجديد</p>
              </div>
              <Switch
                checked={settings.whatsappEnabled === "true"}
                onCheckedChange={(c) => setSettings({ ...settings, whatsappEnabled: c ? "true" : "false" })}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm">قالب رسالة التذكير</Label>
              <Textarea
                value={settings.whatsappTemplate || ""}
                onChange={(e) => setSettings({ ...settings, whatsappTemplate: e.target.value })}
                rows={3}
                placeholder="مرحباً {name}، اشتراكك ينتهي في {date}..."
              />
              <p className="text-xs text-muted-foreground">المتغيرات: {`{name}`} (الاسم)، {`{date}`} (تاريخ الانتهاء)</p>
            </div>
          </section>

          <div className="flex justify-end gap-2 pt-3 border-t">
            <Button onClick={handleSave} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4 ml-1" />}
              حفظ الإعدادات
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
