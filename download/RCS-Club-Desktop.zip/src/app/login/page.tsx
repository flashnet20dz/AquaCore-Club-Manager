"use client";

import { Suspense, useState, useEffect, useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { Waves, Mail, Lock, LogIn, Loader2, Sparkles, AlertCircle, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: string;
}

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const callbackUrl = searchParams.get("callbackUrl") || "/";

  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Auto-fill demo credentials
  useEffect(() => {
    setEmail("admin@rcs.dz");
    setPassword("admin123");
  }, []);

  // Check if already logged in
  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store" })
      .then((r) => r.json())
      .then((data) => {
        if (data.user) {
          window.location.href = callbackUrl;
        }
      })
      .catch(() => {});
  }, [callbackUrl]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "بيانات الدخول غير صحيحة");
        toast.error(data.error || "فشل تسجيل الدخول");
        setLoading(false);
        return;
      }

      toast.success(`مرحباً بك ${data.user.name}`);
      // Full page reload to ensure cookie is sent with the request
      window.location.href = callbackUrl;
    } catch (err) {
      console.error("Login error:", err);
      setError("تعذر الاتصال بالخادم. حاول مرة أخرى.");
      toast.error("خطأ في الاتصال");
    } finally {
      setLoading(false);
    }
  };


  const fillDemo = (demoEmail: string, demoPassword: string) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
    setMode("login");
    setError("");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-teal-600 via-sky-700 to-indigo-800 relative overflow-hidden">
      {/* Decorative waves */}
      <div className="absolute inset-0 opacity-10">
        <svg className="absolute bottom-0 left-0 w-full h-1/2" viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path d="M0,60 C150,100 350,0 600,60 C850,120 1050,20 1200,60 L1200,120 L0,120 Z" fill="white" />
        </svg>
        <svg className="absolute bottom-0 left-0 w-full h-1/3" viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path d="M0,80 C200,40 400,100 600,80 C800,60 1000,100 1200,80 L1200,120 L0,120 Z" fill="white" opacity="0.5" />
        </svg>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center h-28 w-28 rounded-3xl bg-white/15 backdrop-blur-md border border-white/20 mb-3 wave-animation overflow-hidden">
            <img
              src="/images/rcs-logo-official.png"
              alt="شعار نادي RCS"
              className="h-full w-full object-contain p-1"
            />
          </div>
          <div className="space-y-0.5 mb-1">
            <h1 className="text-lg font-extrabold text-white">النادي الهاوي متعدد الرياضات</h1>
            <p className="text-base font-bold text-amber-300">الرائد - سعيدة</p>
            <p className="text-sm text-white/80">فرع السباحة</p>
          </div>
          <p className="text-xs text-white/60 mt-2">منظومة إدارة الاشتراكات</p>
        </div>

        {/* Card */}
        <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/30 p-6">
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 rounded-xl bg-rose-50 border border-rose-200 p-2.5 text-sm text-rose-700"
              >
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </motion.div>
            )}
            <div className="space-y-1.5">
              <Label className="text-sm font-semibold flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5" /> البريد الإلكتروني
              </Label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@rcs.dz"
                className="h-11"
                required
                autoComplete="email"
                dir="ltr"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-semibold flex items-center gap-1.5">
                <Lock className="h-3.5 w-3.5" /> كلمة المرور
              </Label>
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="h-11 pl-10"
                  required
                  autoComplete="current-password"
                  dir="ltr"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-2 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" disabled={loading} className="w-full h-11 text-base">
              {loading ? (
                <><Loader2 className="h-4 w-4 animate-spin" /> جاري الدخول...</>
              ) : (
                <><LogIn className="h-4 w-4 ml-1" /> دخول</>
              )}
            </Button>
          </form>

          {/* Demo credentials hint */}
          <div className="mt-4 pt-4 border-t border-border/60">
            <div className="flex items-start gap-2 text-xs text-muted-foreground bg-muted/40 rounded-lg p-2.5">
              <Sparkles className="h-3.5 w-3.5 text-amber-500 mt-0.5 shrink-0" />
              <div className="space-y-0.5">
                <p className="font-semibold text-foreground/80 mb-1">حسابات تجريبية (انقر للملء التلقائي):</p>
                <button
                  type="button"
                  onClick={() => fillDemo("admin@rcs.dz", "admin123")}
                  className="block text-right hover:text-foreground hover:underline transition w-full"
                >
                  👑 المدير: admin@rcs.dz / admin123
                </button>
                <button
                  type="button"
                  onClick={() => fillDemo("coach@rcs.dz", "coach123")}
                  className="block text-right hover:text-foreground hover:underline transition w-full"
                >
                  🏃 المدرب: coach@rcs.dz / coach123
                </button>
              </div>
            </div>
          </div>
        </div>

        <p className="text-center text-xs text-white/60 mt-4">
          © 2026 نادي RCS — جميع الحقوق محفوظة
        </p>
      </motion.div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-600 via-sky-700 to-indigo-800">
          <div className="text-white">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}
