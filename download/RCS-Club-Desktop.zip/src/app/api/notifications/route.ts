import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";

export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const url = new URL(req.url);
    const unreadOnly = url.searchParams.get("unreadOnly") === "true";

    const where: Record<string, unknown> = {
      OR: [{ userId: user.id }, { userId: null }],
    };
    if (unreadOnly) where.read = false;

    const notifications = await db.notification.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: 50,
    });

    const unreadCount = await db.notification.count({
      where: { OR: [{ userId: user.id }, { userId: null }], read: false },
    });

    return NextResponse.json({ notifications, unreadCount });
  } catch (e) {
    console.error("GET notifications:", e);
    return NextResponse.json({ error: "Internal" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });

    const body = await req.json();
    const { action, id } = body;

    if (action === "markRead" && id) {
      await db.notification.update({
        where: { id },
        data: { read: true },
      });
      return NextResponse.json({ success: true });
    }

    if (action === "markAllRead") {
      await db.notification.updateMany({
        where: { OR: [{ userId: user.id }, { userId: null }], read: false },
        data: { read: true },
      });
      return NextResponse.json({ success: true });
    }

    if (action === "delete" && id) {
      await db.notification.delete({ where: { id } });
      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: "إجراء غير معروف" }, { status: 400 });
  } catch (e) {
    console.error("POST notifications:", e);
    return NextResponse.json({ error: "Internal" }, { status: 500 });
  }
}
