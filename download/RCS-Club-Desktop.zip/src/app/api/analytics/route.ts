import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeSubscriberFields } from "@/lib/rcs";

export async function GET() {
  try {
    const [subscribers, attendances, renewals, payments] = await Promise.all([
      db.subscriber.findMany({ orderBy: { createdAt: "asc" } }),
      db.attendance.findMany({ take: 1000, orderBy: { date: "desc" } }),
      db.renewal.findMany({ orderBy: { createdAt: "desc" } }),
      db.payment.findMany({ orderBy: { date: "desc" } }),
    ]);

    // Revenue evolution (last 6 months)
    const months: { label: string; revenue: number; subscribers: number }[] = [];
    const today = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
      const next = new Date(today.getFullYear(), today.getMonth() - i + 1, 1);
      const monthSubs = subscribers.filter((s) => {
        const cd = new Date(s.createdAt);
        return cd >= d && cd < next;
      });
      const monthRens = renewals.filter((r) => {
        const rd = new Date(r.renewalDate);
        return rd >= d && rd < next;
      });
      const revenue = monthRens.reduce((sum, r) => sum + r.amount, 0);
      months.push({
        label: d.toLocaleDateString("ar-DZ", { month: "short" }),
        revenue,
        subscribers: monthSubs.length,
      });
    }

    // Attendance trend (last 14 days)
    const attendanceTrend: { date: string; count: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      d.setHours(0, 0, 0, 0);
      const next = new Date(d);
      next.setDate(next.getDate() + 1);
      const count = attendances.filter((a) => {
        const ad = new Date(a.date);
        return ad >= d && ad < next;
      }).length;
      attendanceTrend.push({
        date: d.toLocaleDateString("ar-DZ", { day: "numeric", month: "numeric" }),
        count,
      });
    }

    // Age distribution
    const computed = subscribers.map((s) => computeSubscriberFields(s));
    const ageGroups = [
      { label: "أقل من 10", count: computed.filter((s) => s.age < 10).length, color: "#0d9488" },
      { label: "10-13", count: computed.filter((s) => s.age >= 10 && s.age < 14).length, color: "#0891b2" },
      { label: "14-17", count: computed.filter((s) => s.age >= 14 && s.age < 18).length, color: "#6366f1" },
      { label: "18-30", count: computed.filter((s) => s.age >= 18 && s.age < 31).length, color: "#8b5cf6" },
      { label: "أكبر من 30", count: computed.filter((s) => s.age >= 31).length, color: "#d97706" },
    ];

    // Subscription type distribution
    const subTypes = ["/", "OPOW", "DJS", "FCS", "RCS", "POLICE"];
    const subTypeData = subTypes.map((t) => ({
      name: t === "/" ? "عادي" : t,
      value: subscribers.filter((s) => s.subscriptionType === t).length,
    }));

    // Payment status distribution
    const payStatuses = ["مدفوع", "لم يدفع", "تأمين فقط", "اشتراك 300"];
    const payStatusData = payStatuses.map((p) => ({
      name: p,
      value: subscribers.filter((s) => s.paymentStatus === p).length,
      color: p === "مدفوع" ? "#10b981" : p === "لم يدفع" ? "#ef4444" : p === "تأمين فقط" ? "#0ea5e9" : "#f59e0b",
    }));

    // Revenue by subscription type
    const revenueByType = subTypes.map((t) => {
      const subs = computed.filter((s) => s.subscriptionType === t && s.totalAmount !== null);
      return {
        name: t === "/" ? "عادي" : t,
        revenue: subs.reduce((sum, s) => sum + (s.totalAmount ?? 0), 0),
      };
    }).filter((d) => d.revenue > 0);

    return NextResponse.json({
      revenueEvolution: months,
      attendanceTrend,
      ageGroups,
      subTypeData,
      payStatusData,
      revenueByType,
      totals: {
        subscribers: subscribers.length,
        revenue: computed.reduce((s, x) => s + (x.totalAmount ?? 0), 0),
        attendance: attendances.length,
        renewals: renewals.length,
      },
    });
  } catch (e) {
    console.error("Analytics:", e);
    return NextResponse.json({ error: "Internal" }, { status: 500 });
  }
}
