import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  computeSubscriberFields,
  generateFileNumber,
  type Gender,
  type SubscriptionType,
  type PaymentStatus,
} from "@/lib/rcs";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const search = url.searchParams.get("search") || "";
    const paymentStatus = url.searchParams.get("paymentStatus") || "";
    const subscriptionType = url.searchParams.get("subscriptionType") || "";
    const gender = url.searchParams.get("gender") || "";
    const renewalStatus = url.searchParams.get("renewalStatus") || "";

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { lastName: { contains: search } },
        { firstName: { contains: search } },
        { fileNumber: { contains: search } },
        { phone: { contains: search } },
      ];
    }
    if (paymentStatus) where.paymentStatus = paymentStatus;
    if (subscriptionType) where.subscriptionType = subscriptionType;
    if (gender) where.gender = gender;

    const subscribers = await db.subscriber.findMany({
      where,
      orderBy: { createdAt: "asc" },
    });

    const computed = subscribers.map((s) => ({
      ...s,
      ...computeSubscriberFields(s),
    }));

    let filtered = computed;
    if (renewalStatus === "سارية") {
      filtered = computed.filter((s) => s.renewalStatus === "✅ ساري");
    } else if (renewalStatus === "قريبة") {
      filtered = computed.filter((s) => s.renewalStatus === "⚠️ قريب الانتهاء");
    } else if (renewalStatus === "منتهية") {
      filtered = computed.filter((s) => s.renewalStatus === "⛔ منتهي - يتطلب تجديد");
    } else if (renewalStatus === "مجمدة") {
      filtered = computed.filter((s) => s.renewalStatus === "🔒 مجمدة");
    }

    return NextResponse.json({ subscribers: filtered });
  } catch (error) {
    console.error("GET /api/subscribers error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    if (!body.lastName || !body.firstName || !body.birthDate || !body.gender || !body.subscriptionType || !body.paymentStatus) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const count = await db.subscriber.count();
    const fileNumber = generateFileNumber(count + 1);

    const subscriber = await db.subscriber.create({
      data: {
        fileNumber,
        lastName: body.lastName,
        firstName: body.firstName,
        birthDate: new Date(body.birthDate),
        gender: body.gender as Gender,
        bloodType: body.bloodType || null,
        subscriptionType: body.subscriptionType as SubscriptionType,
        lastPaymentDate: body.lastPaymentDate ? new Date(body.lastPaymentDate) : null,
        paymentStatus: body.paymentStatus as PaymentStatus,
        swimmingDays: body.swimmingDays || null,
        timeSlot: body.timeSlot || null,
        phone: body.phone || null,
      },
    });

    await db.activity.create({
      data: {
        subscriberId: subscriber.id,
        type: "create",
        description: `تم تسجيل منخرط جديد: ${subscriber.lastName} ${subscriber.firstName} (${fileNumber})`,
      },
    });

    const fields = computeSubscriberFields(subscriber);
    return NextResponse.json({ subscriber: { ...subscriber, ...fields } }, { status: 201 });
  } catch (error) {
    console.error("POST /api/subscribers error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
