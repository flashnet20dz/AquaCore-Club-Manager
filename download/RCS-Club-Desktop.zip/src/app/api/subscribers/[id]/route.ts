import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeSubscriberFields } from "@/lib/rcs";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const subscriber = await db.subscriber.findUnique({ where: { id } });
    if (!subscriber) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    const fields = computeSubscriberFields(subscriber);
    return NextResponse.json({ subscriber: { ...subscriber, ...fields } });
  } catch (error) {
    console.error("GET /api/subscribers/[id] error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();

    const existing = await db.subscriber.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const subscriber = await db.subscriber.update({
      where: { id },
      data: {
        lastName: body.lastName ?? existing.lastName,
        firstName: body.firstName ?? existing.firstName,
        birthDate: body.birthDate ? new Date(body.birthDate) : existing.birthDate,
        gender: body.gender ?? existing.gender,
        bloodType: body.bloodType !== undefined ? (body.bloodType || null) : existing.bloodType,
        subscriptionType: body.subscriptionType ?? existing.subscriptionType,
        lastPaymentDate: body.lastPaymentDate !== undefined
          ? (body.lastPaymentDate ? new Date(body.lastPaymentDate) : null)
          : existing.lastPaymentDate,
        paymentStatus: body.paymentStatus ?? existing.paymentStatus,
        swimmingDays: body.swimmingDays !== undefined ? (body.swimmingDays || null) : existing.swimmingDays,
        timeSlot: body.timeSlot !== undefined ? (body.timeSlot || null) : existing.timeSlot,
        phone: body.phone !== undefined ? (body.phone || null) : existing.phone,
      },
    });

    await db.activity.create({
      data: {
        subscriberId: subscriber.id,
        type: "update",
        description: `تم تحديث بيانات ${subscriber.lastName} ${subscriber.firstName}`,
      },
    });

    const fields = computeSubscriberFields(subscriber);
    return NextResponse.json({ subscriber: { ...subscriber, ...fields } });
  } catch (error) {
    console.error("PUT /api/subscribers/[id] error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const sub = await db.subscriber.findUnique({ where: { id } });
    if (!sub) return NextResponse.json({ error: "Not found" }, { status: 404 });

    await db.activity.create({
      data: {
        type: "delete",
        description: `تم حذف المنخرط ${sub.lastName} ${sub.firstName} (${sub.fileNumber})`,
      },
    });

    await db.subscriber.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/subscribers/[id] error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
