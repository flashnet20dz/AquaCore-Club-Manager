import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const activities = await db.activity.findMany({
      include: { subscriber: true },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return NextResponse.json({ activities });
  } catch (e) {
    console.error("GET activities:", e);
    return NextResponse.json({ error: "Internal" }, { status: 500 });
  }
}
