import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser, hasPermission } from "@/lib/session";
import { computeSubscriberFields, type Gender, type BloodType, type SubscriptionType, type PaymentStatus, type SwimmingDays, type TimeSlot } from "@/lib/rcs";
import * as XLSX from "xlsx";

// Parse dates in multiple formats:
// - DD/MM/YYYY (Arabic/French format — most common in Algeria)
// - YYYY/MM/DD (ISO format)
// - YYYY-MM-DD (ISO with dashes)
// - DD-MM-YYYY
// - Excel serial numbers
// - Date objects
function parseDate(value: unknown): Date | null {
  if (!value) return null;

  // Already a Date object
  if (value instanceof Date) {
    return isNaN(value.getTime()) ? null : value;
  }

  // Number — Excel serial date (days since 1899-12-30)
  if (typeof value === "number") {
    if (value > 25569 && value < 60000) {
      // Excel serial date
      const ms = (value - 25569) * 86400 * 1000;
      const d = new Date(ms);
      return isNaN(d.getTime()) ? null : d;
    }
    return null;
  }

  if (typeof value !== "string") return null;
  const str = value.trim();
  if (!str) return null;

  // Try DD/MM/YYYY or DD-MM-YYYY (Arabic/French format — preferred)
  // Format: day/month/year
  const dmyMatch = str.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);
  if (dmyMatch) {
    const [, d, m, y] = dmyMatch;
    const day = parseInt(d, 10);
    const month = parseInt(m, 10);
    const year = parseInt(y, 10);
    if (day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1900) {
      const date = new Date(year, month - 1, day);
      return isNaN(date.getTime()) ? null : date;
    }
  }

  // Try YYYY/MM/DD or YYYY-MM-DD (ISO format)
  // Format: year/month/day
  const ymdMatch = str.match(/^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/);
  if (ymdMatch) {
    const [, y, m, d] = ymdMatch;
    const year = parseInt(y, 10);
    const month = parseInt(m, 10);
    const day = parseInt(d, 10);
    if (day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1900) {
      const date = new Date(year, month - 1, day);
      return isNaN(date.getTime()) ? null : date;
    }
  }

  // Try DD/MM/YY (2-digit year)
  const dmy2Match = str.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2})$/);
  if (dmy2Match) {
    const [, d, m, y] = dmy2Match;
    const day = parseInt(d, 10);
    const month = parseInt(m, 10);
    let year = parseInt(y, 10);
    if (year < 50) year += 2000;
    else if (year < 100) year += 1900;
    if (day >= 1 && day <= 31 && month >= 1 && month <= 12) {
      const date = new Date(year, month - 1, day);
      return isNaN(date.getTime()) ? null : date;
    }
  }

  // Fallback: try Date constructor
  const fallback = new Date(str);
  return isNaN(fallback.getTime()) ? null : fallback;
}

// Format date for display (DD/MM/YYYY — Arabic preferred)
function formatDate(date: Date | null): string {
  if (!date) return "";
  const d = date.getDate().toString().padStart(2, "0");
  const m = (date.getMonth() + 1).toString().padStart(2, "0");
  const y = date.getFullYear();
  return `${d}/${m}/${y}`;
}

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || !hasPermission(currentUser.role, "import")) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    }

    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    const dryRun = formData.get("dryRun") === "true";

    if (!file) {
      return NextResponse.json({ error: "لم يتم رفع أي ملف" }, { status: 400 });
    }

    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array", cellDates: true });

    // Find the data sheet (first sheet or sheet named "بيانات")
    const sheetName = wb.SheetNames.find((n) => n.includes("بيانات")) || wb.SheetNames[0];
    const ws = wb.Sheets[sheetName];
    if (!ws) {
      return NextResponse.json({ error: "تعذر العثور على ورقة البيانات" }, { status: 400 });
    }

    // Convert to JSON (header row detection)
    // The Excel file has a title in row 1, headers in row 2, data from row 3
    // sheet_to_json with header:1 returns array of arrays — we find the header row
    const allRows = XLSX.utils.sheet_to_json<unknown[]>(ws, { defval: "", raw: true, header: 1 });

    if (allRows.length === 0) {
      return NextResponse.json({ error: "الملف فارغ" }, { status: 400 });
    }

    // Find the header row — it's the row containing "اللقب" and "الاسم"
    let headerRowIndex = -1;
    for (let i = 0; i < Math.min(5, allRows.length); i++) {
      const row = allRows[i].map((c) => String(c || "").trim().replace(/\r?\n/g, " ").replace(/\s+/g, " "));
      if (row.some((c) => c === "اللقب") && row.some((c) => c === "الاسم")) {
        headerRowIndex = i;
        break;
      }
    }

    if (headerRowIndex === -1) {
      return NextResponse.json({
        error: "تعذر العثور على صف العناوين. تأكد من وجود أعمدة 'اللقب' و 'الاسم'.",
      }, { status: 400 });
    }

    // Build headers from the header row
    const headerRow = allRows[headerRowIndex].map((c) =>
      String(c || "").trim().replace(/\r?\n/g, " ").replace(/\s+/g, " ")
    );

    // Build rows as objects keyed by header
    const rows: Record<string, unknown>[] = [];
    for (let i = headerRowIndex + 1; i < allRows.length; i++) {
      const row = allRows[i];
      if (!row || row.every((c) => !c || String(c).trim() === "")) continue;
      const obj: Record<string, unknown> = {};
      for (let j = 0; j < headerRow.length; j++) {
        if (headerRow[j]) obj[headerRow[j]] = row[j];
      }
      rows.push(obj);
    }

    if (rows.length === 0) {
      return NextResponse.json({ error: "الملف فارغ" }, { status: 400 });
    }

    // Detect column names (handle various Arabic headers from Excel)
    const findKey = (row: Record<string, unknown>, candidates: string[]): string | null => {
      const keys = Object.keys(row);
      for (const candidate of candidates) {
        // Match exact or contains (normalize whitespace)
        const found = keys.find((k) => {
          const normalized = k.trim().replace(/\s+/g, " ");
          return normalized === candidate || normalized.includes(candidate);
        });
        if (found) return found;
      }
      return null;
    };

    const firstRow = rows[0];
    const lastNameKey = findKey(firstRow, ["اللقب"]);
    const firstNameKey = findKey(firstRow, ["الاسم"]);
    const birthDateKey = findKey(firstRow, ["تاريخ الميلاد", "الميلاد"]);
    const genderKey = findKey(firstRow, ["الجنس"]);
    const bloodTypeKey = findKey(firstRow, ["فصيلة الدم", "فصيلة", "الدم"]);
    const subscriptionTypeKey = findKey(firstRow, ["نوع الاشتراك", "الاشتراك"]);
    const lastPaymentKey = findKey(firstRow, ["تاريخ آخر دفعة", "آخر دفعة", "الدفعة"]);
    const paymentStatusKey = findKey(firstRow, ["حالة الدفع"]);
    const swimmingDaysKey = findKey(firstRow, ["أيام السباحة", "الأيام"]);
    const timeSlotKey = findKey(firstRow, ["التوقيت"]);
    const phoneKey = findKey(firstRow, ["الهاتف", "هاتف", "رقم الهاتف"]);

    if (!lastNameKey || !firstNameKey) {
      return NextResponse.json({
        error: "تعذر العثور على أعمدة اللقب والاسم. تأكد من أن الصف الأول يحتوي على العناوين الصحيحة.",
      }, { status: 400 });
    }

    // Valid values
    const validGenders = ["ذكر", "أنثى"];
    const validPaymentStatuses = ["مدفوع", "لم يدفع", "تأمين فقط", "اشتراك 300"];
    const validSubscriptionTypes = ["/", "OPOW", "DJS", "FCS", "RCS", "POLICE"];
    const validBloodTypes = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"];

    interface ParsedRow {
      row: number;
      lastName: string;
      firstName: string;
      birthDate: Date | null;
      birthDateRaw: string;
      gender: string | null;
      bloodType: string | null;
      subscriptionType: string | null;
      lastPaymentDate: Date | null;
      lastPaymentRaw: string;
      paymentStatus: string | null;
      swimmingDays: string | null;
      timeSlot: string | null;
      phone: string | null;
      errors: string[];
    }

    const parsed: ParsedRow[] = [];
    let errorCount = 0;
    let warnings = 0;

    rows.forEach((row, idx) => {
      const r: ParsedRow = {
        row: idx + 2,
        lastName: String(row[lastNameKey] || "").trim(),
        firstName: String(row[firstNameKey] || "").trim(),
        birthDate: null,
        birthDateRaw: "",
        gender: null,
        bloodType: null,
        subscriptionType: null,
        lastPaymentDate: null,
        lastPaymentRaw: "",
        paymentStatus: null,
        swimmingDays: null,
        timeSlot: null,
        phone: null,
        errors: [],
      };

      if (!r.lastName || !r.firstName) {
        r.errors.push("اللقب أو الاسم فارغ");
      }

      // Parse birth date — supports DD/MM/YYYY and YYYY/MM/DD
      if (birthDateKey) {
        const bd = row[birthDateKey];
        r.birthDateRaw = bd ? String(bd) : "";
        r.birthDate = parseDate(bd);
        if (r.birthDate === null && bd && String(bd).trim()) {
          r.errors.push(`تاريخ ميلاد غير صالح: "${bd}" (الصيغ المقبولة: DD/MM/YYYY أو YYYY/MM/DD)`);
        } else if (!bd || !String(bd).trim()) {
          r.errors.push("تاريخ الميلاد فارغ");
        }
      } else {
        r.errors.push("عمود تاريخ الميلاد غير موجود");
      }

      // Gender
      if (genderKey) {
        const g = String(row[genderKey] || "").trim();
        if (validGenders.includes(g)) {
          r.gender = g;
        } else if (g) {
          r.errors.push(`جنس غير صالح: "${g}" (يجب أن يكون "ذكر" أو "أنثى")`);
        }
      }

      // Blood type (optional)
      if (bloodTypeKey) {
        const b = String(row[bloodTypeKey] || "").trim();
        if (b === "" || b === "/") {
          r.bloodType = null;
        } else if (validBloodTypes.includes(b)) {
          r.bloodType = b;
        } else {
          r.errors.push(`فصيلة دم غير صالحة: "${b}"`);
          warnings++;
        }
      }

      // Subscription type
      if (subscriptionTypeKey) {
        const t = String(row[subscriptionTypeKey] || "").trim();
        if (t === "" || validSubscriptionTypes.includes(t)) {
          r.subscriptionType = t || "/";
        } else {
          r.errors.push(`نوع اشتراك غير صالح: "${t}"`);
        }
      } else {
        r.subscriptionType = "/";
      }

      // Last payment date — supports DD/MM/YYYY and YYYY/MM/DD
      if (lastPaymentKey) {
        const lp = row[lastPaymentKey];
        r.lastPaymentRaw = lp ? String(lp) : "";
        if (lp && String(lp).trim()) {
          r.lastPaymentDate = parseDate(lp);
          if (r.lastPaymentDate === null) {
            r.errors.push(`تاريخ دفعة غير صالح: "${lp}"`);
          }
        }
      }

      // Payment status
      if (paymentStatusKey) {
        const p = String(row[paymentStatusKey] || "").trim();
        if (validPaymentStatuses.includes(p)) {
          r.paymentStatus = p;
        } else if (p) {
          r.errors.push(`حالة دفع غير صالحة: "${p}"`);
        } else {
          r.paymentStatus = "لم يدفع";
        }
      } else {
        r.paymentStatus = "لم يدفع";
      }

      // Swimming days
      if (swimmingDaysKey) {
        r.swimmingDays = String(row[swimmingDaysKey] || "").trim() || null;
      }

      // Time slot
      if (timeSlotKey) {
        r.timeSlot = String(row[timeSlotKey] || "").trim() || null;
      }

      // Phone
      if (phoneKey) {
        r.phone = String(row[phoneKey] || "").trim() || null;
      }

      if (r.errors.length > 0) errorCount++;
      parsed.push(r);
    });

    // Filter valid rows
    const validRows = parsed.filter((r) =>
      r.errors.length === 0 &&
      r.lastName &&
      r.firstName &&
      r.birthDate &&
      r.gender &&
      r.subscriptionType &&
      r.paymentStatus
    );

    // Compute financial summary for valid rows (verification)
    const financialCheck = validRows.map((r) => {
      const mockSub = {
        birthDate: r.birthDate!,
        paymentStatus: r.paymentStatus as PaymentStatus,
        subscriptionType: r.subscriptionType as SubscriptionType,
        lastPaymentDate: r.lastPaymentDate,
      };
      const c = computeSubscriberFields(mockSub);
      return {
        ...r,
        birthDateDisplay: formatDate(r.birthDate),
        lastPaymentDisplay: formatDate(r.lastPaymentDate),
        computed: c,
        expectedCompoundRights: c.compoundRights,
        // Verify: total 2000/1800/1500/1300 → 1000 rights
        rightsRule: c.totalAmount && [1300, 1500, 1800, 2000].includes(c.totalAmount) ? "1000 دج للديوان" : "مستثنى",
      };
    });

    if (dryRun) {
      return NextResponse.json({
        preview: true,
        totalRows: rows.length,
        validRows: validRows.length,
        errorRows: errorCount,
        warnings,
        detectedColumns: {
          lastName: lastNameKey,
          firstName: firstNameKey,
          birthDate: birthDateKey,
          gender: genderKey,
          bloodType: bloodTypeKey,
          subscriptionType: subscriptionTypeKey,
          lastPaymentDate: lastPaymentKey,
          paymentStatus: paymentStatusKey,
          swimmingDays: swimmingDaysKey,
          timeSlot: timeSlotKey,
          phone: phoneKey,
        },
        sample: financialCheck.slice(0, 10),
        errorSamples: parsed.filter((r) => r.errors.length > 0).slice(0, 10),
        summary: {
          totalFees: financialCheck.reduce((s, r) => s + (r.computed.subscriptionFee ?? 0), 0),
          totalInsurance: financialCheck.reduce((s, r) => s + (r.computed.insuranceFee ?? 0), 0),
          totalCompound: financialCheck.reduce((s, r) => s + (r.computed.compoundRights ?? 0), 0),
          totalRevenue: financialCheck.reduce((s, r) => s + (r.computed.totalAmount ?? 0), 0),
        },
      });
    }

    // Actually import
    const existingCount = await db.subscriber.count();
    let imported = 0;
    let skipped = 0;
    const importErrors: { row: number; name: string; error: string }[] = [];

    for (const r of validRows) {
      try {
        const fileNumber = `RCS ${String(existingCount + imported + 1).padStart(3, "0")}`;
        await db.subscriber.create({
          data: {
            fileNumber,
            lastName: r.lastName,
            firstName: r.firstName,
            birthDate: r.birthDate!,
            gender: r.gender as Gender,
            bloodType: (r.bloodType as BloodType) || null,
            subscriptionType: r.subscriptionType as SubscriptionType,
            lastPaymentDate: r.lastPaymentDate,
            paymentStatus: r.paymentStatus as PaymentStatus,
            swimmingDays: (r.swimmingDays as SwimmingDays) || null,
            timeSlot: (r.timeSlot as TimeSlot) || null,
            phone: r.phone,
          },
        });
        imported++;
      } catch (e) {
        skipped++;
        importErrors.push({
          row: r.row,
          name: `${r.lastName} ${r.firstName}`,
          error: e instanceof Error ? e.message : "خطأ غير معروف",
        });
      }
    }

    // Log activity
    await db.activity.create({
      data: {
        type: "import",
        description: `تم استيراد ${imported} منخرط من ملف Excel`,
      },
    });

    return NextResponse.json({
      success: true,
      imported,
      skipped,
      totalRows: rows.length,
      errors: importErrors,
    });
  } catch (e) {
    console.error("Import error:", e);
    return NextResponse.json({ error: "خطأ داخلي: " + (e instanceof Error ? e.message : "") }, { status: 500 });
  }
}
