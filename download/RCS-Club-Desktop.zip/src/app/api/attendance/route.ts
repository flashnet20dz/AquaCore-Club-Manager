import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const date = url.searchParams.get("date");
    const subscriberId = url.searchParams.get("subscriberId");

    const where: Record<string, unknown> = {};
    if (date) {
      const d = new Date(date);
      const next = new Date(d);
      next.setDate(next.getDate() + 1);
      where.date = { gte: d, lt: next };
    }
    if (subscriberId) where.subscriberId = subscriberId;

    const attendances = await db.attendance.findMany({
      where,
      include: { subscriber: true },
      orderBy: { checkInTime: "desc" },
    });

    return NextResponse.json({ attendances });
  } catch (e) {
    console.error("GET attendance:", e);
    return NextResponse.json({ error: "Internal" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { subscriberId, method, date, note } = body;

    if (!subscriberId) {
      return NextResponse.json({ error: "subscriberId required" }, { status: 400 });
    }

    const sub = await db.subscriber.findUnique({ where: { id: subscriberId } });
    if (!sub) return NextResponse.json({ error: "Subscriber not found" }, { status: 404 });

    const today = date ? new Date(date) : new Date();
    today.setHours(0, 0, 0, 0);

    const existing = await db.attendance.findUnique({
      where: { subscriberId_date: { subscriberId, date: today } },
    });

    if (existing) {
      return NextResponse.json({ error: "تم تسجيل الحضور اليوم", attendance: existing }, { status: 409 });
    }

    const checkIn = new Date();
    const attendance = await db.attendance.create({
      data: {
        subscriberId,
        date: today,
        checkInTime: checkIn,
        method: method || "manual",
        note: note || null,
      },
      include: { subscriber: true },
    });

    await db.activity.create({
      data: {
        subscriberId,
        type: "attendance",
        description: `حضر ${sub.lastName} ${sub.firstName} حصة اليوم`,
      },
    });

    return NextResponse.json({ attendance }, { status: 201 });
  } catch (e) {
    console.error("POST attendance:", e);
    return NextResponse.json({ error: "Internal" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db.attendance.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("DELETE attendance:", e);
    return NextResponse.json({ error: "Internal" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, checkOut } = body;
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

    const attendance = await db.attendance.update({
      where: { id },
      data: checkOut ? { checkOutTime: new Date() } : {},
    });

    return NextResponse.json({ attendance });
  } catch (e) {
    console.error("PATCH attendance:", e);
    return NextResponse.json({ error: "Internal" }, { status: 500 });
  }
}
