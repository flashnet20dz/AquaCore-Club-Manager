import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeSubscriberFields } from "@/lib/rcs";

// This endpoint can be called by a cron job (e.g., Vercel Cron) to generate notifications
// GET /api/cron/notifications — generates renewal reminders
export async function GET() {
  try {
    const subscribers = await db.subscriber.findMany();
    const computed = subscribers.map((s) => ({ ...s, ...computeSubscriberFields(s) }));

    const expiringSoon = computed.filter((s) => s.renewalStatus === "⚠️ قريب الانتهاء");
    const expired = computed.filter((s) => s.renewalStatus === "⛔ منتهي - يتطلب تجديد");

    let created = 0;
    const admins = await db.user.findMany({ where: { role: "admin", active: true } });

    for (const sub of expiringSoon) {
      const existing = await db.notification.findFirst({
        where: {
          type: "renewal",
          createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
          message: { contains: sub.fileNumber },
        },
      });
      if (!existing) {
        for (const admin of admins) {
          await db.notification.create({
            data: {
              userId: admin.id,
              type: "renewal",
              title: "اشتراك قريب الانتهاء",
              message: `${sub.lastName} ${sub.firstName} (${sub.fileNumber}) — ينتهي في ${sub.expiryDate ? new Date(sub.expiryDate).toLocaleDateString("ar-DZ") : "قريب"}`,
              link: "/?tab=renewals",
            },
          });
          created++;
        }
      }
    }

    for (const sub of expired) {
      const existing = await db.notification.findFirst({
        where: {
          type: "renewal",
          createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
          message: { contains: sub.fileNumber },
        },
      });
      if (!existing) {
        for (const admin of admins) {
          await db.notification.create({
            data: {
              userId: admin.id,
              type: "renewal",
              title: "⚠️ اشتراك منتهي",
              message: `${sub.lastName} ${sub.firstName} (${sub.fileNumber}) — اشتراك منتهي ويحتاج تجديد`,
              link: "/?tab=renewals",
            },
          });
          created++;
        }
      }
    }

    return NextResponse.json({
      success: true,
      created,
      expiringSoon: expiringSoon.length,
      expired: expired.length,
    });
  } catch (e) {
    console.error("Cron notifications:", e);
    return NextResponse.json({ error: "Internal" }, { status: 500 });
  }
}
