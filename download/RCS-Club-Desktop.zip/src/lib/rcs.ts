/**
 * Business logic for RCS subscription system
 * Mirrors the Excel formulas:
 * - Subscription fee (AF): based on age + subscription type + payment status
 * - Insurance fee (AG): 500 DA when paid
 * - Compound rights (AH): 1000 DA except for exempt categories
 * - Total amount (AI) = subscription fee + insurance fee
 */

export type Gender = "ذكر" | "أنثى";
export type BloodType = "A+" | "A-" | "B+" | "B-" | "O+" | "O-" | "AB+" | "AB-";
export type SubscriptionType = "/" | "OPOW" | "DJS" | "FCS" | "RCS" | "POLICE" | "MJ";
export type PaymentStatus = "مدفوع" | "لم يدفع" | "تأمين فقط" | "اشتراك 300";
export type SwimmingDays = "الأحد والأربعاء" | "الاثنين والخميس" | "الثلاثاء والجمعة" | "كل الأيام";
export type TimeSlot = "09:00-10:00" | "10:00-11:00" | "19:00-20:00" | "20:00-21:00";

export interface SubscriberWithComputed {
  id: string;
  fileNumber: string;
  lastName: string;
  firstName: string;
  birthDate: Date;
  gender: Gender;
  bloodType: BloodType | null;
  subscriptionType: SubscriptionType;
  lastPaymentDate: Date | null;
  paymentStatus: PaymentStatus;
  swimmingDays: SwimmingDays | null;
  timeSlot: TimeSlot | null;
  phone: string | null;
  createdAt: Date;
  updatedAt: Date;
  // Computed
  age: number;
  expiryDate: Date | null;
  subscriptionFee: number | null;
  insuranceFee: number | null;
  compoundRights: number | null;
  totalAmount: number | null;
  renewalStatus: string;
}

export const SUBSCRIPTION_FEE_REGULAR_UNDER_14 = 1300;
export const SUBSCRIPTION_FEE_REGULAR_OVER_14 = 1500;
export const SUBSCRIPTION_FEE_DISCOUNTED = 300; // OPOW, DJS, POLICE, اشتراك 300
export const SUBSCRIPTION_FEE_EXEMPT = 0; // FCS, RCS, تأمين فقط
export const INSURANCE_FEE = 500;
export const COMPOUND_RIGHTS = 1000;

export function calculateAge(birthDate: Date): number {
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}

export function calculateExpiryDate(lastPaymentDate: Date | null): Date | null {
  if (!lastPaymentDate) return null;
  const expiry = new Date(lastPaymentDate);
  expiry.setDate(expiry.getDate() + 30);
  return expiry;
}

export function calculateSubscriptionFee(
  paymentStatus: PaymentStatus,
  subscriptionType: SubscriptionType,
  age: number
): number | null {
  if (paymentStatus === "لم يدفع") return null;
  if (subscriptionType === "MJ") {
    return 0; // MJ: لا يدفع رسوم الاشتراك
  }
  if (paymentStatus === "تأمين فقط" || subscriptionType === "FCS" || subscriptionType === "RCS") {
    return SUBSCRIPTION_FEE_EXEMPT;
  }
  if (
    paymentStatus === "اشتراك 300" ||
    subscriptionType === "POLICE" ||
    subscriptionType === "OPOW" ||
    subscriptionType === "DJS"
  ) {
    return SUBSCRIPTION_FEE_DISCOUNTED;
  }
  return age < 14 ? SUBSCRIPTION_FEE_REGULAR_UNDER_14 : SUBSCRIPTION_FEE_REGULAR_OVER_14;
}

export function calculateInsuranceFee(paymentStatus: PaymentStatus, subscriptionType?: SubscriptionType): number | null {
  if (subscriptionType === "MJ") return 0; // MJ: لا يدفع مصاريف التأمين
  if (paymentStatus === "لم يدفع") return null;
  return INSURANCE_FEE;
}

export function calculateCompoundRights(
  paymentStatus: PaymentStatus,
  subscriptionType: SubscriptionType
): number | null {
  if (paymentStatus === "لم يدفع") return null;
  if (
    subscriptionType === "MJ" || // MJ: لا حقوق مركب
    paymentStatus === "تأمين فقط" ||
    paymentStatus === "اشتراك 300" ||
    subscriptionType === "OPOW" ||
    subscriptionType === "DJS" ||
    subscriptionType === "FCS" ||
    subscriptionType === "RCS" ||
    subscriptionType === "POLICE"
  ) {
    return null; // exempt
  }
  return COMPOUND_RIGHTS;
}

export function calculateTotalAmount(
  paymentStatus: PaymentStatus,
  subscriptionFee: number | null,
  insuranceFee: number | null
): number | null {
  if (paymentStatus === "لم يدفع") return null;
  if (subscriptionFee === null) return null;
  // Per user requirement: Total = subscription fee + insurance fee
  // (compound rights are excluded from total per the Excel AI formula)
  return subscriptionFee + (insuranceFee ?? 0);
}

export function calculateRenewalStatus(
  paymentStatus: PaymentStatus,
  expiryDate: Date | null
): string {
  if (paymentStatus === "لم يدفع") return "🔒 مجمدة";
  if (!expiryDate) return "";
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate);
  expiry.setHours(0, 0, 0, 0);
  if (expiry < today) return "⛔ منتهي - يتطلب تجديد";
  const fiveDaysBefore = new Date(expiry);
  fiveDaysBefore.setDate(fiveDaysBefore.getDate() - 5);
  if (fiveDaysBefore <= today) return "⚠️ قريب الانتهاء";
  return "✅ ساري";
}

export function computeSubscriberFields<T extends {
  birthDate: Date;
  paymentStatus: PaymentStatus;
  subscriptionType: SubscriptionType;
  lastPaymentDate: Date | null;
}>(sub: T): Omit<SubscriberWithComputed, keyof T | "id" | "fileNumber" | "lastName" | "firstName" | "gender" | "bloodType" | "swimmingDays" | "timeSlot" | "createdAt" | "updatedAt"> {
  const age = calculateAge(sub.birthDate);
  const expiryDate = calculateExpiryDate(sub.lastPaymentDate);
  const subscriptionFee = calculateSubscriptionFee(sub.paymentStatus, sub.subscriptionType, age);
  const insuranceFee = calculateInsuranceFee(sub.paymentStatus, sub.subscriptionType);
  const compoundRights = calculateCompoundRights(sub.paymentStatus, sub.subscriptionType);
  const totalAmount = calculateTotalAmount(sub.paymentStatus, subscriptionFee, insuranceFee);
  const renewalStatus = calculateRenewalStatus(sub.paymentStatus, expiryDate);

  return {
    age,
    expiryDate,
    subscriptionFee,
    insuranceFee,
    compoundRights,
    totalAmount,
    renewalStatus,
  };
}

export function generateFileNumber(index: number): string {
  return `RCS ${String(index).padStart(3, "0")}`;
}

// Status colors for badges
export const PAYMENT_STATUS_COLORS: Record<PaymentStatus, string> = {
  "مدفوع": "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
  "لم يدفع": "bg-rose-500/15 text-rose-700 dark:text-rose-300 border-rose-500/30",
  "تأمين فقط": "bg-sky-500/15 text-sky-700 dark:text-sky-300 border-sky-500/30",
  "اشتراك 300": "bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30",
};

export const SUBSCRIPTION_TYPE_COLORS: Record<SubscriptionType, string> = {
  "/": "bg-teal-500/15 text-teal-700 dark:text-teal-300 border-teal-500/30",
  "OPOW": "bg-violet-500/15 text-violet-700 dark:text-violet-300 border-violet-500/30",
  "DJS": "bg-fuchsia-500/15 text-fuchsia-700 dark:text-fuchsia-300 border-fuchsia-500/30",
  "FCS": "bg-cyan-500/15 text-cyan-700 dark:text-cyan-300 border-cyan-500/30",
  "RCS": "bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 border-indigo-500/30",
  "POLICE": "bg-slate-500/15 text-slate-700 dark:text-slate-300 border-slate-500/30",
  "MJ": "bg-orange-500/15 text-orange-700 dark:text-orange-300 border-orange-500/30",
};

export const RENEWAL_STATUS_COLORS: Record<string, string> = {
  "✅ ساري": "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
  "⚠️ قريب الانتهاء": "bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30",
  "⛔ منتهي - يتطلب تجديد": "bg-rose-500/15 text-rose-700 dark:text-rose-300 border-rose-500/30",
  "🔒 مجمدة": "bg-slate-500/15 text-slate-700 dark:text-slate-300 border-slate-500/30",
};

export const SUBSCRIPTION_TYPES: SubscriptionType[] = ["/", "OPOW", "DJS", "FCS", "RCS", "POLICE", "MJ"];
export const PAYMENT_STATUSES: PaymentStatus[] = ["مدفوع", "لم يدفع", "تأمين فقط", "اشتراك 300"];
export const BLOOD_TYPES: BloodType[] = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"];
export const SWIMMING_DAYS: SwimmingDays[] = ["الأحد والأربعاء", "الاثنين والخميس", "الثلاثاء والجمعة", "كل الأيام"];
export const TIME_SLOTS: TimeSlot[] = ["09:00-10:00", "10:00-11:00", "19:00-20:00", "20:00-21:00"];
