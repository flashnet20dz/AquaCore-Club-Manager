import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { cookies } from "next/headers";
import type { Role, SessionUser } from "@/lib/roles";

// Re-export for backward compatibility
export type { Role, SessionUser };
export { ROLE_LABELS, ROLE_ICONS, hasPermission } from "@/lib/roles";

export const SESSION_COOKIE = "rcs-session";
const SESSION_MAX_AGE = 30 * 24 * 60 * 60; // 30 days

// In-memory session store (resets on server restart, but fine for dev/single-instance)
// For production, this should be in DB or Redis
const sessionStore = new Map<string, { user: SessionUser; expires: number }>();

// Cleanup expired sessions periodically
function cleanupSessions() {
  const now = Date.now();
  for (const [key, val] of sessionStore.entries()) {
    if (val.expires < now) sessionStore.delete(key);
  }
}

function generateToken(): string {
  // Cryptographically random token
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");
}

export async function createUser(email: string, password: string, name: string, phone?: string): Promise<SessionUser> {
  const existing = await db.user.findUnique({ where: { email: email.toLowerCase().trim() } });
  if (existing) throw new Error("هذا البريد مسجل بالفعل");

  const passwordHash = await bcrypt.hash(password, 10);
  const userCount = await db.user.count();
  const role = userCount === 0 ? "admin" : "coach";

  const user = await db.user.create({
    data: {
      email: email.toLowerCase().trim(),
      name,
      passwordHash,
      phone: phone || null,
      role,
    },
  });

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    phone: user.phone,
  };
}

export async function verifyCredentials(email: string, password: string): Promise<SessionUser | null> {
  try {
    const user = await db.user.findUnique({
      where: { email: email.toLowerCase().trim() },
    });
    if (!user) return null;
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return null;
    return {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      phone: user.phone,
    };
  } catch (e) {
    console.error("Verify credentials error:", e);
    return null;
  }
}

export async function createSession(user: SessionUser): Promise<string> {
  cleanupSessions();
  const token = generateToken();
  sessionStore.set(token, {
    user,
    expires: Date.now() + SESSION_MAX_AGE * 1000,
  });
  return token;
}

export function getSessionFromToken(token: string | undefined): SessionUser | null {
  if (!token) return null;
  cleanupSessions();
  const session = sessionStore.get(token);
  if (!session) return null;
  if (session.expires < Date.now()) {
    sessionStore.delete(token);
    return null;
  }
  return session.user;
}

export async function getCurrentUser(): Promise<SessionUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  return getSessionFromToken(token);
}

export async function setSessionCookie(token: string) {
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: false, // allow preview deployments on http
    path: "/",
    maxAge: SESSION_MAX_AGE,
  });
}

export async function clearSessionCookie() {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE);
}

export async function destroySession(token: string | undefined) {
  if (token) {
    sessionStore.delete(token);
  }
  await clearSessionCookie();
}
