// Role definitions and permission helpers (safe for client and server)
export type Role = "admin" | "assistant" | "lifeguard" | "observer";

export const ROLE_LABELS: Record<Role, string> = {
  admin: "مدير",
  assistant: "مساعد إداري",
  lifeguard: "حارس سباحة",
  observer: "مراقب",
};

export const ROLE_ICONS: Record<Role, string> = {
  admin: "👑",
  assistant: "💼",
  lifeguard: "🏊",
  observer: "👁️",
};

// Check if user has permission for a feature
export function hasPermission(role: string | undefined, feature: string): boolean {
  if (!role) return false;
  const permissions: Record<string, Role[]> = {
    dashboard: ["admin", "assistant", "lifeguard", "observer"],
    subscribers: ["admin", "assistant"],
    attendance: ["admin", "assistant", "lifeguard", "observer"],
    renewals: ["admin", "assistant"],
    export: ["admin", "assistant"],
    workHours: ["admin", "assistant", "lifeguard"],
    workHoursApproval: ["admin", "assistant"],
    userManagement: ["admin"],
    settings: ["admin"],
    cards: ["admin", "assistant"],
    import: ["admin", "assistant"],
  };
  return permissions[feature]?.includes(role as Role) || false;
}

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: string;
  phone?: string | null;
}
