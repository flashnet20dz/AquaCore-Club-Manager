// eslint-disable-next-line @typescript-eslint/no-require-imports
// electron/main.ts — العملية الرئيسية لـ Electron
// يقوم بتشغيل خادم Next.js وفتح نافذة التطبيق

const { app, BrowserWindow, Menu, shell, ipcMain } = require("electron");
const path = require("path");
const { spawn } = require("child_process");
const http = require("http");

let mainWindow: any = null;
let nextServer: any = null;
const PORT = 3000;

// التحقق من أن خادم Next.js جاهز
function waitForServer(url: string, callback: () => void) {
  const check = () => {
    http
      .get(url, (res: any) => {
        if (res.statusCode === 200) {
          callback();
        } else {
          setTimeout(check, 500);
        }
      })
      .on("error", () => {
        setTimeout(check, 500);
      });
  };
  check();
}

// تشغيل خادم Next.js
function startNextServer() {
  const isDev = !app.isPackaged;
  const serverPath = isDev
    ? path.join(__dirname, "..", "node_modules", ".bin", "next")
    : path.join(process.resourcesPath, "app", "node_modules", ".bin", "next");

  const args = isDev
    ? ["dev", "-p", String(PORT), "-H", "0.0.0.0"]
    : ["start", "-p", String(PORT), "-H", "0.0.0.0"];

  nextServer = spawn(serverPath, args, {
    cwd: isDev ? path.join(__dirname, "..") : process.resourcesPath,
    shell: true,
    env: { ...process.env, PORT: String(PORT) },
  });

  nextServer.stdout?.on("data", (data: any) => {
    console.log(`[Next.js] ${data}`);
  });

  nextServer.stderr?.on("data", (data: any) => {
    console.error(`[Next.js Error] ${data}`);
  });
}

// إنشاء نافذة التطبيق
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    title: "نادي RCS — منظومة إدارة الاشتراكات",
    icon: path.join(__dirname, "..", "public", "images", "rcs-logo-official.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
    show: false,
    backgroundColor: "#0f766e",
  });

  // إظهار النافذة عند الجاهزية
  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
  });

  // تحميل الصفحة
  waitForServer(`http://localhost:${PORT}`, () => {
    mainWindow.loadURL(`http://localhost:${PORT}`);
  });

  // فتح الروابط الخارجية في المتصفح
  mainWindow.webContents.setWindowOpenHandler(({ url }: any) => {
    shell.openExternal(url);
    return { action: "deny" };
  });

  // القائمة
  const template: any = [
    {
      label: "ملف",
      submenu: [
        { label: "طباعة", accelerator: "CmdOrCtrl+P", click: () => mainWindow.webContents.print() },
        { type: "separator" },
        { label: "خروج", accelerator: "CmdOrCtrl+Q", click: () => app.quit() },
      ],
    },
    {
      label: "تحرير",
      submenu: [
        { label: "تراجع", role: "undo" },
        { label: "إعادة", role: "redo" },
        { type: "separator" },
        { label: "قص", role: "cut" },
        { label: "نسخ", role: "copy" },
        { label: "لصق", role: "paste" },
      ],
    },
    {
      label: "عرض",
      submenu: [
        { label: "تكبير", role: "zoomIn" },
        { label: "تصغير", role: "zoomOut" },
        { label: "حجم طبيعي", role: "resetZoom" },
        { type: "separator" },
        { label: "ملء الشاشة", role: "togglefullscreen" },
      ],
    },
    {
      label: "مساعدة",
      submenu: [
        {
          label: "عن البرنامج",
          click: () => {
            const { dialog } = require("electron");
            dialog.showMessageBox(mainWindow, {
              type: "info",
              title: "عن نادي RCS",
              message: "نادي RCS — منظومة إدارة الاشتراكات",
              detail: "الإصدار 1.0.0\nالنادي الهاوي متعدد الرياضات\nالرائد - سعيدة\nفرع السباحة",
              buttons: ["حسناً"],
            });
          },
        },
        {
          label: "التحقق من التحديثات",
          click: () => {
            require("./auto-updater").checkForUpdates();
          },
        },
      ],
    },
  ];

  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// عند جاهزية التطبيق
app.whenReady().then(() => {
  startNextServer();
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// عند إغلاق جميع النوافذ
app.on("window-all-closed", () => {
  if (nextServer) {
    nextServer.kill();
  }
  app.quit();
});

// قبل الخروج
app.on("before-quit", () => {
  if (nextServer) {
    nextServer.kill();
  }
});

// IPC: طباعة مباشرة
ipcMain.handle("print", async () => {
  mainWindow.webContents.print({ silent: false, printBackground: true });
});

// IPC: الحصول على عنوان IP المحلي
ipcMain.handle("get-local-ip", () => {
  const os = require("os");
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === "IPv4" && !iface.internal) {
        return iface.address;
      }
    }
  }
  return "127.0.0.1";
});
