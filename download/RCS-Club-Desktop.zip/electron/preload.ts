// eslint-disable-next-line @typescript-eslint/no-require-imports
// electron/preload.ts — جسر بين Electron والصفحة
// يعرض وظائف آمنة للتطبيق

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
  // طباعة مباشرة
  print: () => ipcRenderer.invoke("print"),

  // الحصول على عنوان IP المحلي
  getLocalIP: () => ipcRenderer.invoke("get-local-ip"),

  // معلومات التطبيق
  appVersion: "1.0.0",
  isElectron: true,

  // التحديثات
  checkForUpdates: () => ipcRenderer.invoke("check-for-updates"),
});
